Python 3.10.8 (tags/v3.10.8:aaaf517, Oct 11 2022, 16:50:30) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
datasetread = pd.read_csv("CSDataset.csv", header=None, names=None)
datasetread.head()
   0   1      2   3   4    5    6   ...   23  24    25    26    27    28    29
0   0   3  20000   1   1  5.0  5.0  ...  1.0   1  50.0  50.0  50.0  50.0   0.0
1   0   2  11305   1   1  3.0  3.0  ...  1.0   2  50.0  50.0  30.0  50.0  30.0
2   1   3  18671   0   1  1.0  4.0  ...  2.0   3  20.0  30.0   0.0  20.0   0.0
3   1   2  20000   1   1  4.0  3.0  ...  1.0   2  50.0  50.0  10.0  10.0  10.0
4   1   2  12000   0   2  3.0  3.0  ...  1.0   2  50.0  50.0   0.0  30.0  50.0

[5 rows x 30 columns]
>>> pd.set_option("display.max.columns", None)
>>> datasetread.head()
   0   1      2   3   4    5    6    7   8    9   10  11  12  13  14  15  16  \
0   0   3  20000   1   1  5.0  5.0  3.0   1  0.0   3   1   3   3   1   1   2   
1   0   2  11305   1   1  3.0  3.0  3.0   1  1.0   3   3   3   2   2   2   2   
2   1   3  18671   0   1  1.0  4.0  3.0   4  0.0   3   2   1   3   1   3   1   
3   1   2  20000   1   1  4.0  3.0  3.0   1  1.0   3   2   1   3   3   2   3   
4   1   2  12000   0   2  3.0  3.0  2.0   5  1.0   3   2   3   2   3   2   2   

   17  18  19  20  21  22   23  24    25    26    27    28    29  
0   1   1   1   1   1   1  1.0   1  50.0  50.0  50.0  50.0   0.0  
1   1   1   1   2   2   1  1.0   2  50.0  50.0  30.0  50.0  30.0  
2   5   1   1   1   1   2  2.0   3  20.0  30.0   0.0  20.0   0.0  
3   1   2   2   1   1   2  1.0   2  50.0  50.0  10.0  10.0  10.0  
4   1   1   1   2   3   1  1.0   2  50.0  50.0   0.0  30.0  50.0  
>>> datasetread = pd.read_csv("CSDataset1.csv", header=None, names=None)
>>> pd.set_option("display.max.columns", None)
>>> datasetread.head()
   0   1      2   3   4    5    6    7   8    9   10  11  12  13  14  15  16  \
0   0   3  20000   1   1  5.0  5.0  3.0   1  0.0   3   1   3   3   1   1   2   
1   0   2  11305   1   1  3.0  3.0  3.0   1  1.0   3   3   3   2   2   2   2   
2   1   3  18671   0   1  1.0  4.0  3.0   4  0.0   3   2   1   3   1   3   1   
3   1   2  20000   1   1  4.0  3.0  3.0   1  1.0   3   2   1   3   3   2   3   
4   1   2  12000   0   2  3.0  3.0  2.0   5  1.0   3   2   3   2   3   2   2   

   17  18  19  20  21  22   23  24    25    26    27    28    29  30  
0   1   1   1   1   1   1  1.0   1  50.0  50.0  50.0  50.0   0.0   1  
1   1   1   1   2   2   1  1.0   2  50.0  50.0  30.0  50.0  30.0   1  
2   5   1   1   1   1   2  2.0   3  20.0  30.0   0.0  20.0   0.0   0  
3   1   2   2   1   1   2  1.0   2  50.0  50.0  10.0  10.0  10.0   1  
4   1   1   1   2   3   1  1.0   2  50.0  50.0   0.0  30.0  50.0   1  
>>> X = datasetread[dataset_cols]
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    X = datasetread[dataset_cols]
NameError: name 'dataset_cols' is not defined
